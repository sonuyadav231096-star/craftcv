# CraftCV — Setup & Deployment Guide

## Project Structure
```
craftcv/
├── index.html           ← Frontend (CV builder + Razorpay UI)
├── api/
│   ├── create-order.js  ← Vercel function: create Razorpay order
│   └── verify-payment.js← Vercel function: verify payment signature
├── package.json
├── vercel.json
└── README.md
```

---

## Step 1 — Razorpay Account Setup

1. Go to https://razorpay.com → Sign up (free)
2. Complete KYC (Aadhaar + PAN + Bank account)
3. Dashboard → Settings → API Keys → Generate Test Key
4. Note down:
   - `Key ID`     → starts with `rzp_test_...`
   - `Key Secret` → keep this SECRET, never put in frontend

---

## Step 2 — Add Your Keys to index.html

Open `index.html`, find this at the top of the `<script>` section:

```javascript
const CONFIG = {
  RAZORPAY_KEY: 'rzp_test_XXXXXXXXXXXXXXXX',  // ← paste your Key ID here
  ...
};
```

Replace `rzp_test_XXXXXXXXXXXXXXXX` with your actual Key ID.

---

## Step 3 — Deploy to Vercel (Free)

### 3a. Install Vercel CLI
```bash
npm install -g vercel
```

### 3b. Login
```bash
vercel login
```

### 3c. Deploy
```bash
cd craftcv
vercel
```
Follow prompts. After deploy you'll get a URL like:
`https://craftcv-abc123.vercel.app`

### 3d. Set Environment Variables on Vercel
Go to: Vercel Dashboard → Your Project → Settings → Environment Variables

Add these two:
| Name                   | Value                    |
|------------------------|--------------------------|
| RAZORPAY_KEY_ID        | rzp_test_XXXXXXXXXX      |
| RAZORPAY_KEY_SECRET    | your_secret_key_here     |

### 3e. Update API_BASE in index.html
```javascript
const CONFIG = {
  RAZORPAY_KEY: 'rzp_test_XXXXXXXXXX',
  API_BASE: 'https://craftcv-abc123.vercel.app',  // ← your Vercel URL
  ...
};
```

Then redeploy: `vercel --prod`

---

## Step 4 — Test Payment

1. Open your Vercel URL
2. Click "Upgrade ₹199"
3. Use test card:
   - Card: `4111 1111 1111 1111`
   - Expiry: any future date
   - CVV: any 3 digits
   - OTP: `1234`
4. After success → premium features unlock ✅

---

## Step 5 — Go Live

1. Razorpay Dashboard → Complete KYC fully
2. Once approved, get Live keys (`rzp_live_...`)
3. Replace test keys with live keys in Vercel env vars
4. Redeploy → `vercel --prod`

---

## Pricing Strategy Ideas

| Plan       | Price  | Features                          |
|------------|--------|-----------------------------------|
| Free       | ₹0     | Classic template only             |
| Premium    | ₹199   | All templates + AI + PDF export   |
| Pro Bundle | ₹499   | Premium + custom domain resume    |

---

## Support
If payment works but premium doesn't unlock → check browser console for errors.
Most common issue: wrong API_BASE URL in CONFIG.
