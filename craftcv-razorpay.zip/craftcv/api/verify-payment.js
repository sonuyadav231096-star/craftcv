const crypto = require('crypto');

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ success: false, error: 'Missing payment details' });
  }

  try {
    // Verify signature using Razorpay secret
    const body      = razorpay_order_id + '|' + razorpay_payment_id;
    const expected  = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(body)
      .digest('hex');

    if (expected !== razorpay_signature) {
      return res.status(400).json({ success: false, error: 'Invalid signature — payment tampered' });
    }

    // ✅ Payment is genuine
    // Here you can: save to DB, send email, generate token, etc.
    // For now we return a simple unlock token
    const unlockToken = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(razorpay_payment_id + '_craftcv_premium')
      .digest('hex')
      .substring(0, 32);

    return res.status(200).json({
      success:      true,
      payment_id:   razorpay_payment_id,
      unlockToken,  // frontend stores this to keep premium unlocked
    });
  } catch (err) {
    console.error('Verification error:', err);
    return res.status(500).json({ success: false, error: 'Verification failed' });
  }
}
